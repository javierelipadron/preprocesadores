# Bienvenidos a Orbit

**_Orbit_** es un conjunto de archivos **.scss** que trabajan sobre **_Bootstrap Twitter 3_** para personalizar los componentes que posee dicho Framework, de forma de adaptarlo a las necesidades de CUPRUM en el  diseño de sitios y aplicaciones web.

Dado que los archivos SCSS son CSS preprocesado, es necesario usar alguna herramienta para llevarlo desde .**scss** (archivos sass) a .**css**. Para ello usaremos en este caso **Webpack.**

Webpack es un es un sistema de empaquetamiento (bundling) para preparar el desarrollo de una aplicación web para producción. Su principal función es transpilar y preprocesar código de .**scss** a .**css**, de ES7 a ES5/6 entre otras.

## Requisitos

 - Nodejs v 8.10.0 LTS   
   ([https://nodejs.org/es/](https://nodejs.org/es/))
 - Descarga del Proyecto webpack desde GIT o algún repositorio
 - Accedemos a CMD ó GIT CMD
 
## Como usarlo
  - Acceder via comando a la carpeta del proyecto y colocar los comandos:
    - npm install
    - npm run build
  - Una vez ejecutado, nuestro archivo generado de .css estará ubicado en    la carpeta **/dist** en el archivo **/dist/bundle.css**, usando este archivo tendras todas las caracteristicas de Orbit en tu proyecto.

## Demo de Orbit
  
  Para poder ver un demo del styling de Orbit en conjunto con Bootstrap 3.3.7 puedes acceder al archivo **index.html**

## Como mejorar y adaptar a mis necesidades los archivos de Orbit

Una vez tenemos el proyecto es posible añadir archivos **.scss** o modificar el código a los archivos .**scss**, que lo componen. Una vez realizados los cambios se puede generar usando **Webpack** el archivo final que podrá ser usado por nuestra aplicación, este archivo será un **.css** comprimido.

## Archivos Javascript que son base del proyecto:

 - https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js
 - https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js

## Estructura de Carpetas

- /src
	- /includes
	- /updates-cuprum
		- updates-cuprum.scss
		- /variables
			- typography.scss
			- panel.scss
			- nav.scss
			- loaders.scss
			- icons.scss
			- highlight.scss
			- forms.scss
			- buttons.scss
			- body.scss
			- alert.scss
- /node_modules
- package.json
- app.js
- webpack.config
- index.html
- dist
	- bundle.css
	- bundle.js