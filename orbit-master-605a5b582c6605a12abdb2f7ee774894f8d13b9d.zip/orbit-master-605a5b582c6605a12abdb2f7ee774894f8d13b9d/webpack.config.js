var ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
  entry: [ './src/includes/updates-cuprum/updates-cuprum.scss'],
  output: {
    filename: 'dist/bundle.js'
  },
  module: {
    rules: [
      /*
      your other rules for JavaScript transpiling go in here
      */
      { // css / sass / scss loader for webpack
        test: /\.(css|sass|scss)$/,
        use: ExtractTextPlugin.extract({
          use: [{ loader: 'css-loader' , options: { minimize: true }}, { loader: 'sass-loader' , options: { minimize: true }}],
        })
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin({ // define where to save the file
      filename: 'dist/bundle.css',
      allChunks: true,
    }),
  ],
};
